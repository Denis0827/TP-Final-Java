

window.onload = function() {
    if (sessionStorage.getItem("usuarioEnLinea") == null){ window.location.href = "../index.html"; };
    if (sessionStorage.getItem("esadmin") == null){ window.location.href = "../index.html";};
}