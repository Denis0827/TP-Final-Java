package ar.cac;

public class logon {

        public int id;
        public String email;
        public String contrasena;
        public Boolean activo;
        public Boolean admin;
        
        public int getId() {
            return id;
        }
        public void setId(int id) {
            this.id = id;
        }
        public String getEmail() {
            return email;
        }
        public void setEmail(String email) {
            this.email = email;
        }
        public String getContrasena() {
            return contrasena;
        }
        public void setContrasena(String contrasena) {
            this.contrasena = contrasena;
        }
        public Boolean getActivo() {
            return activo;
        }
        public void setActivo(Boolean activo) {
            this.activo = activo;
        }
        public Boolean getAdmin() {
            return admin;
        }
        public void setAdmin(Boolean admin) {
            this.admin = admin;
        }

    
       
    
    
}
